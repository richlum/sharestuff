<html><body><h1>Test logging into your Oracle account</h1>


<form method="post" action="oracle-parmtest.php">
AccountId(ora_x#x#): <input type="text" size="10" maxlength="40" name="name"> <br />
Password: <input type="password" size="10" maxlength="10" name="password">
<br/>
<input type="submit" value="Send"> 
</form>



</body>

</html>


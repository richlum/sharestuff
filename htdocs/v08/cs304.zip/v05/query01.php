<html>
<body>

THIS IS QUERY 01

<br />
<?php echo $_GET['myperson'];?>
<br />
<?php 	$mylocalvar = $_GET['myperson'];
	echo  "mylocalvar for using with queries = $mylocalvar" ;?>
</body>
</html>


<html>
<body>
<?php 
	$aaa = "testomg";
	echo $aaa;
	$bbb = "parm"
?>
<br />
this is some html text
<br />
<?php echo $bbb; ?>
<br />
<?php
	echo $aaa;
?>
<br />
<?php 
	echo $_GET["$bbb"];
	echo $_GET['arg1'];
?>
</body>
</html>


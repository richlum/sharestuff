<html>

<body>
This is testr
<br />
<?php  echo  $town; ?>
<br />
get[town] = 
<?php	echo $_GET['town']; ?>
<br />
get[user]=  
<?php	echo $_GET['user']; ?>
<br />
_POST[town]= 
<?php echo  $_POST['town']; ?>
<br />
_POST[user]= 
<?php	echo  $_POST['user']; ?>
<br />
GLOBALS[selectedUser]= 
<?php	echo  $GLOBALS['selectedUser']; ?>
</ body>
</html>

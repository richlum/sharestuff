<html>
<body>


<br />
myperson = 
<?php echo $_GET['myperson'];?>
<br/>
itemid = 
<?php echo $_GET['itemid'];?>
<br />
</body>
</html>

